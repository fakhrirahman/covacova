public class TestResizableCircle {
	public static void main(String[] args) {
		ResizableCircle rc = new ResizableCircle(25.0);
		ResizableCircle rcb = new ResizableCircle(25+ 25*rc.resize(15));
		System.out.println("Perimeter after resize = " + rcb.getPerimeter());
		System.out.println("Area after resize = " + rcb.getArea());
	}
}