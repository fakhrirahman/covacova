public class DiscountRate {
	private double serviceDiscountPremium = 0.2;
	private double serviceDiscountGold = 0.15;
	private double serviceDiscountSilver = 0.1;
	private double productDiscountPremium = 0.1;
	private double productDiscountGold = 0.1;
	private double productDiscountSilver = 0.1;

	public double getServiceDiscount(String type) {
		switch(type) {
			case "Premium":
						return this.serviceDiscountPremium;
						break;
			case "Gold":
						return this.serviceDiscountGold;
						break;
			case "Silver":
						return this.serviceDiscountSilver;
						break;
		}
	}

	public double getProductDiscountRate(String type) {
		switch(type) {
			case "Premium":
						return this.productDiscountPremium;
						break;
			case "Gold":
						return this.productDiscountGold;
						break;
			case "Silver":
						return this.productDiscountSilver;
						break;
		}
	}
}