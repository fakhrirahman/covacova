public class Visit {
	private Customer customer;
	private Date date;
	private double serviceExpense;
	private double productExpense;

	public Visit(String name, Date date) {
		this.name = name;
		this.date = date;
	}

	public String getName() {
		return this.name;
	}

	public double getServiceExpense() {
		return this.serviceExpense;
	}

	public double setServiceExpense(double ex) {
		this.serviceExpense = ex;
	}

	public double getProductExpense() {
		return this.productExpense;
	}

	public double setProductExpense(double ex) {
		this.productExpense = ex;
	}	
}