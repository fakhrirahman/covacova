public class TestAnimal {
	public static void main(String[] args) {
		System.out.println("Author: 140810160062 Muhammad Islam Taufikurahman");
		String[] df = new String[4];
		df[0] = "Fish";
		df[1] = "Meal";
		df[2] = "Chicken";
		df[3] = "Whiskas";
		Animal dog = new Dog(10, df);
		dog.setFur("Smooth");

		String[] af = new String[4];
		af[0] = "Leaf";
		af[1] = "Meal";
		af[2] = "Plant";
		af[3] = "Hay";
		Animal an = new Animal(10, af);

		AnimalArray ar = new AnimalArray();

		ar.addAnimal(dog);
		ar.addAnimal(an);
		ar.printAllAnimal();
	}
}