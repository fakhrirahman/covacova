public class Dog extends Animal {
	private String fur;

	public Dog(int weight, String fur) {
		super(weight);
		this.fur = fur;
	}

	public Dog(int weight, String[] foodList, String fur) {
		super(weight, foodList);
		this.fur = fur;
	}

	public void setFur(String fur) {
		this.fur = fur;
	}

	public String getFur() {
		return this.fur;
	}

	public void sound() {
		System.out.println("Sound : Woof!");
	}
}