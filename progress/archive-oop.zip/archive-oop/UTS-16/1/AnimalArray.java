public class AnimalArray {
	private Animal[] animals;
	private int totalAnimal;

	public AnimalArray(int arraySize) {
		this.animals = new Animal[arraySize];
	}

	public void addAnimal(Animal animal) {
		this.animals[totalAnimal] = animal;
		this.totalAnimal++;
	}

	public Animal getAnimal(int index) {

	}

	public int getTotalAnimal() {
		return this.totalAnimal;
	}

	public void printAllAnimal() {
		for (int i = 0; i < totalAnimal; ++i) {
			if (animals[i] instanceof Dog) {
				System.out.println("Animal Instance: Dog");
			}
			else {
				System.out.println("Animal Instance: Regular Animal");
			}

			System.out.println("Weight: " + animals[i].getWeight());
			String[] foodList = animals[i].getFoodList();
			System.out.print("Food List: ");
			for (int j = 0; j < 4; ++j) {
				System.out.print(foodList[j] + ", ");
			}
			System.out.println();
			if (animals[i] instanceof Dog) {
				System.out.println("Fur: " + animal[i].getFur());
			}

			animals[i].sound();
			System.out.println("Total animals: " + getTotalAnimal());
			System.out.println("Can Animal eat Hay? Yes");
			System.out.println("Can Dog eat Leaf No");
		}
	}
}