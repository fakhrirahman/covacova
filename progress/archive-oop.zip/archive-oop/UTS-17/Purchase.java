public class Purchase implements IPurchase{
    private Buyer buyers;
    private Car[] cars;
    private int totalPurchase;

    public Purchase(Buyer buyer){
        this.buyers = buyer;
        this.cars = new Car[99];
    }

    @Override
    public void addCar(Car car) {
        this.cars[totalPurchase++] = car;
    }

    @Override
    public int getTotalPurchase() {
        return this.totalPurchase++;
    }

    @Override
    public void printPurchases() {
        System.out.println(this.buyers.getName());
        System.out.println(this.buyers.getAddress());
        System.out.println("---");
        for(int i=0;i<this.totalPurchase;i++){
            System.out.println(""+ (i+1) +". " + this.cars[i].getName());
            System.out.println("Price\t\t$" + this.cars[i].getPrice());
            
            if(cars[i] instanceof Truck){
                Truck t = (Truck) cars[i];
                System.out.println("Max Capacity\t" + t.getMaxCapacity()+ "CC\n");
            } else {
                SuperCar s = (SuperCar) cars[i];
                System.out.println("Top Speed\t" + s.getTopSpeed()+ "MPH\n");
            }
        }
    }
}
