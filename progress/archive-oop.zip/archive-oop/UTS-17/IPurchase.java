public interface IPurchase{
    void printPurchases();
    void addCar(Car car);
    int getTotalPurchase();
}
