public class TestProgram{
    public static void main(String[] args) {
        Car hino = new Truck("Hino Dutro",120000, 5000);
        Car consignment = new SuperCar("Consignment", 800000, 300);

        Buyer argil = new Buyer("Argil", "Puri Indah");
        
        Purchase struk = new Purchase(argil);

        struk.addCar(hino);
        struk.addCar(consignment);
        struk.printPurchases();
    }
}
