
// Alur program
//
// Hitung nilai 'h' ??????
// Hitung nilai hash untuk 'pola' 
// Hitung substring dari 'text' berjumlah pola.length
// 
// loop untuk cek per blok teks, digeser 1 ke kanan untuk tiap perulangan
// jika nilai hash 'pola' == substring dari 'text', cek karakter 'pola' dan substring 'teks' satu persatu
// jika karakter pada 'pola' dan substring dari 'teks' sama, print output
// jika tidak memenuhi, maju satu indeks ke kanan, lalu cari nilai hash substring 'text' selanjutnya
// jika nilai hash bernilai negatif, ubah dulu ke positif
// ulang 
// 
import java.util.Scanner;
public class TestCase {
    // d adalah jumlah karakter pada input alphabet
    public final static int d = 256;
     
    // pola -> pola
    // text -> text
    // bPrima -> bilangan prima
    
    static void search(String pola, String text, int bPrima){
        int pjgPola = pola.length(); //jumlah karakter dari pola
        int pjgText = text.length(); //jumlah karakter dari text
        int i, j; // untuk iterasi
        int hashPola = 0; // hash value untuk pola
        int hashText = 0; // hash value untuk teks
        int h = 1; //?
     
        // value dari 'h' = "pow(d, M-1)%bPrima"
        for (i = 0; i < pjgPola-1; i++){
            h = (h*d)%bPrima;
        }
     
        // hitung hash dari 'pola' dan 'text' untuk pertama kali
        for (i = 0; i < pjgPola; i++){
            hashPola = (d*hashPola + pola.charAt(i)) % bPrima;
            hashText = (d*hashText + text.charAt(i)) % bPrima;

        }
     
        // geser dan cek setiap pola dengan substring satu persatu
        for (i = 0; i <= pjgText - pjgPola; i++){
     
            // jika nilai hash pola == hash text
            if ( hashPola == hashText ){
                // lakukan cek karakter satu persatu
                for (j = 0; j < pjgPola; j++){
                    
                    if (text.charAt(i+j) != pola.charAt(j))
                        break;
                }
                // print, jika ternyata nilai hash, dan tiap karakter = sama
                if (j == pjgPola)
                    System.out.println("Pola ditemukan pada indeks " + i);
            }
     
            // Hitung hash untuk blok selanjutnya
            if ( i < pjgText-pjgPola ){
                hashText = (d*(hashText - text.charAt(i)*h) + text.charAt(i+pjgPola)) % bPrima;
                // jika nilai hashing bernilai positif
                // ubah ke bentuk positif
                if (hashText < 0)
                hashText = (hashText + bPrima);
            }
        }
    }
     
    // Main Program
    public static void main(String[] args){
        Scanner reader = new Scanner(System.in);

        System.out.println("Teks:");
        String text = reader.nextLine();

        System.out.println("Pola:");
        String pola = reader.nextLine();
        int bPrima = 101; // A prime number
        search(pola, text, bPrima);
    }
}
 
