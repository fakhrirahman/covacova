public class Main {
    // d adalah jumlah karakter pada input alphabet
    public final static int d = 256;
     
    /* pola -> pola
       text -> text
       bPrima -> bilangan prima
    */
    static void search(String pola, String text, int bPrima)
    {
        int pjgPola = pola.length(); //jumlah karakter dari pola
        int pjgText = text.length(); //jumlah karakter dari text
        int i, j; // untuk iterasi
        int hashPola = 0; // hash value untuk pola
        int hashText = 0; // hash value untuk teks
        int h = 1; //?
     
        // value dari 'h' = "pow(d, M-1)%bPrima"
        for (i = 0; i < pjgPola-1; i++)
            h = (h*d)%bPrima;
     
        // Calculate the hash value of polatern and first
        // window of text
        for (i = 0; i < pjgPola; i++){
            hashPola = (d*hashPola + pola.charAt(i))%bPrima;
            hashText = (d*hashText + text.charAt(i))%bPrima;
        }
     
        // Slide the polatern over text one by one
        for (i = 0; i <= pjgText - pjgPola; i++)
        {
     
            // Check the hash values of current window of text
            // and polatern. If the hash values match then only
            // check for characters on by one
            if ( hashPola == hashText ){
                /* Check for characters one by one */
                for (j = 0; j < pjgPola; j++){
                    if (text.charAt(i+j) != pola.charAt(j))
                        break;
                }
     
                // if p == t and pola[0...M-1] = text[i, i+1, ...i+M-1]
                if (j == pjgPola)
                    System.out.println("Pola ditemukan pada indeks " + i);
            }
     
            // Calculate hash value for next window of text: Remove
            // leading digit, add trailing digit
            if ( i < pjgText-pjgPola )
            {
                hashText = (d*(hashText - text.charAt(i)*h) + text.charAt(i+pjgPola))%bPrima;
     
                // We might get negative value of t, converting it
                // to positive
                if (hashText < 0)
                hashText = (hashText + bPrima);
            }
        }
    }
     
    /* Driver program to test above function */
    public static void main(String[] args)
    {
        String text = "GEEKS FOR GEEKS";
        String pola = "GEEK";
        int bPrima = 101; // A prime number
        search(pola, text, bPrima);
    }
}
 
// This code is contributed by nuclode